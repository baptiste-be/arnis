use crate::block_definitions::AIR;
use crate::coordinate_system::cartesian::XZBBox;
use crate::coordinate_system::geographic::LLBBox;
use crate::luanti_block_map::{to_luanti_node, LuantiGame};
use crate::progress::emit_gui_progress_update;
use crate::world_editor::common::{WorldToModify, MIN_Y};
use colored::Colorize;
use fastnbt::Value;
use rayon::prelude::*;
use rusqlite::Connection;
use std::fs;
use std::io::Write;
use std::path::Path;

/// Mapblock format version — 29 uses zstd compression for the entire block
const MAP_FORMAT_VERSION: u8 = 29;

/// 16×16×16 nodes per mapblock
const NODES_PER_BLOCK: usize = 16 * 16 * 16;

/// Encode a mapblock position (x, y, z) into the SQLite integer key.
///
/// Uses the legacy single-integer encoding for compatibility with Luanti 5.5.0+:
/// `pos = z * 0x1000000 + y * 0x1000 + x`
fn encode_block_pos(x: i32, y: i32, z: i32) -> i64 {
    (z as i64) * 0x1000000 + (y as i64) * 0x1000 + (x as i64)
}

/// Serialize a mapblock into the v29 binary format (zstd-compressed).
///
/// The mapblock contains 16×16×16 nodes. Each node has:
/// - param0: content ID (u16) — mapped to block-local IDs via name-id mapping
/// - param1: lighting (u8) — lower nibble = day light, upper nibble = night light
/// - param2: rotation/facedir (u8)
///
/// Returns `(encoded_pos, blob)` ready for SQLite insertion.
fn serialize_mapblock(
    block_x: i32,
    block_y: i32,
    block_z: i32,
    section: &crate::world_editor::common::SectionToModify,
    game: LuantiGame,
) -> std::io::Result<(i64, Vec<u8>)> {
    // Build name-ID mapping: collect unique node names in this mapblock
    let mut name_to_local_id: std::collections::HashMap<&'static str, u16> =
        std::collections::HashMap::new();
    let mut local_id_to_name: Vec<&str> = Vec::new();

    // Pre-populate with air (always ID 0 for efficiency)
    let air_node = to_luanti_node(AIR, game, None);
    name_to_local_id.insert(air_node.name, 0);
    local_id_to_name.push(air_node.name);

    // Arrays for the 4096 nodes
    let mut param0 = vec![0u16; NODES_PER_BLOCK];
    let mut param1 = vec![0u8; NODES_PER_BLOCK];
    let mut param2 = vec![0u8; NODES_PER_BLOCK];

    // SectionToModify uses (u8,u8,u8) get_block returning Option<Block>
    // Luanti serialization order is ZYX (z varies slowest)
    // Luanti Z+ = North, but internal data has Z+ = South (Minecraft convention).
    // We flip Z within each mapblock: serialized z reads from internal (15 - z).
    for sz in 0u8..16 {
        for y in 0u8..16 {
            for x in 0u8..16 {
                let serial_idx = (sz as usize) * 256 + (y as usize) * 16 + (x as usize); // ZYX
                let internal_z = 15 - sz;

                let block = section.get_block(x, y, internal_z).unwrap_or(AIR);
                let props_idx =
                    crate::world_editor::common::SectionToModify::index(x, y, internal_z);
                let props = section.properties.get(&props_idx).map(|v| v as &Value);
                let node = to_luanti_node(block, game, props);

                let local_id = if let Some(&id) = name_to_local_id.get(node.name) {
                    id
                } else {
                    let id = local_id_to_name.len() as u16;
                    name_to_local_id.insert(node.name, id);
                    local_id_to_name.push(node.name);
                    id
                };

                param0[serial_idx] = local_id;
                param2[serial_idx] = node.param2;
            }
        }
    }

    // Intra-mapblock sunlight propagation: for each (x,z) column, scan top-down.
    // If we encounter air, it gets full sunlight (day=15). Once we hit a solid
    // (non-air) block, all air below it is dark (day=0). This is a heuristic that
    // works correctly for roofed buildings and underground spaces within one mapblock.
    // Cross-mapblock boundaries are handled by the engine via lighting_complete flags.
    for sz in 0u8..16 {
        for x in 0u8..16 {
            let mut has_sunlight = true;
            for y in (0u8..16).rev() {
                let idx = (sz as usize) * 256 + (y as usize) * 16 + (x as usize);
                if param0[idx] == 0 {
                    // Air node: gets sunlight if no solid block above in this mapblock
                    param1[idx] = if has_sunlight { 15 } else { 0 };
                } else {
                    // Solid block: blocks sunlight, param1 stays 0
                    has_sunlight = false;
                }
            }
        }
    }

    // Build the uncompressed mapblock buffer (everything after the version byte)
    let mut buf: Vec<u8> = Vec::with_capacity(16384);

    // flags: is_underground (blocks below y=-1), day_night_differs, generated
    let mut flags: u8 = 0x02 | 0x08; // day_night_differs + generated
    if block_y < -1 {
        flags |= 0x01; // is_underground
    }
    buf.push(flags);

    // lighting_complete: upper 4 "nothing" bits must always be set per spec;
    // lower 12 boundary flags cleared = engine recalculates boundary lighting.
    buf.extend_from_slice(&0xF000u16.to_be_bytes());

    // timestamp
    buf.extend_from_slice(&0xFFFFFFFFu32.to_be_bytes());

    // name-id mapping (v29: comes before node data)
    buf.push(0); // name_id_mapping_version
    buf.extend_from_slice(&(local_id_to_name.len() as u16).to_be_bytes());
    for (i, name) in local_id_to_name.iter().enumerate() {
        buf.extend_from_slice(&(i as u16).to_be_bytes());
        buf.extend_from_slice(&(name.len() as u16).to_be_bytes());
        buf.extend_from_slice(name.as_bytes());
    }

    // content_width and params_width
    buf.push(2); // content_width (u16 per node)
    buf.push(2); // params_width (param1 + param2)

    // Node data: param0 (u16 BE), param1 (u8), param2 (u8) — all in ZYX order
    for &p0 in &param0 {
        buf.extend_from_slice(&p0.to_be_bytes());
    }
    buf.extend_from_slice(&param1);
    buf.extend_from_slice(&param2);

    // Node metadata: empty (version 2, count 0)
    buf.push(2); // metadata version
    buf.extend_from_slice(&0u16.to_be_bytes()); // count = 0

    // Static objects
    buf.push(0); // version
    buf.extend_from_slice(&0u16.to_be_bytes()); // count = 0

    // Node timers (v25+ format, placed after static objects in v29)
    buf.push(10); // data length per timer (2 + 4 + 4)
    buf.extend_from_slice(&0u16.to_be_bytes()); // count = 0

    let compressed = zstd::bulk::compress(&buf, 3)?;
    let mut blob = Vec::with_capacity(1 + compressed.len());
    blob.push(MAP_FORMAT_VERSION);
    blob.extend_from_slice(&compressed);

    let pos = encode_block_pos(block_x, block_y, block_z);
    Ok((pos, blob))
}

/// Find a spawn position that is outdoors on solid ground.
/// Trees, leaves and other plants that shouldn't be a spawn surface.
fn non_ground_blocks() -> [crate::block_definitions::Block; 12] {
    use crate::block_definitions::*;
    [
        OAK_LOG,
        OAK_LEAVES,
        BIRCH_LOG,
        BIRCH_LEAVES,
        DARK_OAK_LOG,
        DARK_OAK_LEAVES,
        JUNGLE_LOG,
        JUNGLE_LEAVES,
        ACACIA_LOG,
        ACACIA_LEAVES,
        SPRUCE_LOG,
        SPRUCE_LEAVES,
    ]
}

/// Spirals outward from (center_x, center_z) looking for a column where
/// there is solid ground (not trees/leaves) with air above.
fn find_safe_spawn(
    world: &WorldToModify,
    center_x: i32,
    center_z: i32,
    ground_level: i32,
) -> (i32, i32, i32) {
    use crate::block_definitions::*;
    let non_ground = non_ground_blocks();
    let y_max = ground_level + 400;
    for radius in 0i32..=40 {
        for dx in -radius..=radius {
            for dz in -radius..=radius {
                if dx.abs() != radius && dz.abs() != radius {
                    continue;
                }
                let x = center_x + dx;
                let z = center_z + dz;
                for y in (ground_level..=y_max).rev() {
                    let block = world.get_block(x, y, z);
                    if let Some(b) = block {
                        if b == AIR || non_ground.contains(&b) {
                            continue;
                        }
                        let above1 = world.get_block(x, y + 1, z);
                        let above2 = world.get_block(x, y + 2, z);
                        if (above1.is_none()
                            || above1 == Some(AIR)
                            || non_ground.contains(&above1.unwrap()))
                            && (above2.is_none()
                                || above2 == Some(AIR)
                                || non_ground.contains(&above2.unwrap()))
                        {
                            return (x, y + 1, z);
                        }
                        break;
                    }
                }
            }
        }
    }
    (center_x, ground_level + 3, center_z)
}

/// Single-column spawn-Y lookup used when an explicit spawn (x, z) is given.
/// Scans a wide vertical range so columns below ground_level (e.g. ocean) still resolve.
/// Requires 2 blocks of air clearance above to avoid spawning embedded in a wall/roof.
fn find_spawn_y_at_column(
    world: &WorldToModify,
    x: i32,
    z: i32,
    ground_level: i32,
) -> (i32, i32, i32) {
    use crate::block_definitions::*;
    let non_ground = non_ground_blocks();
    let y_min = (ground_level - 100).max(MIN_Y);
    let y_max = ground_level + 400;
    let clear = |b: Option<crate::block_definitions::Block>| -> bool {
        b.is_none() || b == Some(AIR) || non_ground.contains(&b.unwrap())
    };
    for y in (y_min..=y_max).rev() {
        if let Some(b) = world.get_block(x, y, z) {
            if b == AIR || non_ground.contains(&b) {
                continue;
            }
            if clear(world.get_block(x, y + 1, z)) && clear(world.get_block(x, y + 2, z)) {
                return (x, y + 1, z);
            }
        }
    }
    (x, ground_level + 3, z)
}

/// Creates all Luanti world files and writes the map database.
#[allow(clippy::too_many_arguments)]
pub fn save_luanti_world(
    world: &WorldToModify,
    world_dir: &Path,
    xzbbox: &XZBBox,
    _llbbox: &LLBBox,
    game: LuantiGame,
    level_name: Option<&str>,
    spawn_point: Option<(i32, i32)>,
    ground_level: i32,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("{} Saving Luanti world...", "[7/7]".bold());
    emit_gui_progress_update(90.0, "Saving Luanti world...");

    // Create world directory if needed
    fs::create_dir_all(world_dir)?;

    let (spawn_x, spawn_y, spawn_z) = if let Some((sx, sz)) = spawn_point {
        // Explicit spawn: only scan the single column, no perimeter search.
        find_spawn_y_at_column(world, sx, sz, ground_level)
    } else {
        let cx = (xzbbox.min_x() + xzbbox.max_x()) / 2;
        let cz = (xzbbox.min_z() + xzbbox.max_z()) / 2;
        find_safe_spawn(world, cx, cz, ground_level)
    };

    // Convert spawn Z from internal (Z+ = South) to Luanti (Z+ = North)
    let spawn_z = -spawn_z - 1;

    // Write world.mt
    write_world_mt(world_dir, game, level_name, spawn_x, spawn_y, spawn_z)?;

    // Write map_meta.txt
    write_map_meta(world_dir, game)?;

    // Write env_meta.txt
    write_env_meta(world_dir)?;

    // Write worldmod for singlenode mapgen + spawn
    write_worldmod(world_dir, spawn_x, spawn_y, spawn_z, game)?;

    // Remove stale mod storage so fix_light runs again on regenerated worlds
    let mod_storage_sqlite = world_dir.join("mod_storage.sqlite");
    if mod_storage_sqlite.exists() {
        let _ = fs::remove_file(&mod_storage_sqlite);
    }
    // Also remove any WAL/journal files for mod_storage
    let _ = fs::remove_file(world_dir.join("mod_storage.sqlite-wal"));
    let _ = fs::remove_file(world_dir.join("mod_storage.sqlite-journal"));
    let _ = fs::remove_file(world_dir.join("mod_storage.sqlite-shm"));

    // Write map.sqlite
    write_map_database(world, world_dir, game)?;

    emit_gui_progress_update(99.0, "Luanti world saved.");
    println!(
        "{} Luanti world saved to: {}",
        "Done!".green().bold(),
        world_dir.display()
    );

    Ok(())
}

fn write_world_mt(
    world_dir: &Path,
    game: LuantiGame,
    level_name: Option<&str>,
    spawn_x: i32,
    spawn_y: i32,
    spawn_z: i32,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mut f = fs::File::create(world_dir.join("world.mt"))?;
    writeln!(f, "backend = sqlite3")?;
    writeln!(f, "player_backend = sqlite3")?;
    writeln!(f, "auth_backend = sqlite3")?;
    writeln!(f, "mod_storage_backend = sqlite3")?;
    writeln!(f, "gameid = {}", game.game_id())?;
    if let Some(name) = level_name {
        writeln!(f, "world_name = {}", name)?;
    }
    writeln!(f, "creative_mode = true")?;
    writeln!(f, "enable_damage = false")?;
    writeln!(f, "server_announce = false")?;
    writeln!(
        f,
        "static_spawnpoint = {}, {}, {}",
        spawn_x, spawn_y, spawn_z
    )?;
    Ok(())
}

fn write_map_meta(
    world_dir: &Path,
    game: LuantiGame,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mut f = fs::File::create(world_dir.join("map_meta.txt"))?;
    writeln!(f, "mg_name = singlenode")?;
    writeln!(f, "seed = 0")?;
    if game == LuantiGame::Mineclonia {
        // Tell Mineclonia not to activate its custom levelgen system,
        // so it won't generate terrain over our pre-built map.
        writeln!(f, "mcl_singlenode_mapgen = false")?;
    }
    writeln!(f, "[end_of_params]")?;
    Ok(())
}

fn write_env_meta(world_dir: &Path) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mut f = fs::File::create(world_dir.join("env_meta.txt"))?;
    writeln!(f, "game_time = 0")?;
    writeln!(f, "time_of_day = 6000")?;
    writeln!(f, "EnvArgsEnd")?;
    Ok(())
}

fn write_worldmod(
    world_dir: &Path,
    spawn_x: i32,
    spawn_y: i32,
    spawn_z: i32,
    game: LuantiGame,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mod_dir = world_dir.join("worldmods").join("arnis_mapgen");
    fs::create_dir_all(&mod_dir)?;

    // Write mod.conf (optional_depends on mcl_spawn so we load after Mineclonia's spawn)
    let mut mc = fs::File::create(mod_dir.join("mod.conf"))?;
    writeln!(mc, "name = arnis_mapgen")?;
    writeln!(
        mc,
        "description = Arnis world configuration (singlenode mapgen + spawn)"
    )?;
    writeln!(mc, "optional_depends = mcl_spawn")?;

    if game == LuantiGame::Mineclonia {
        // Write mcl_levelgen.conf to inhibit Mineclonia's custom mapgen
        let mut lc = fs::File::create(mod_dir.join("mcl_levelgen.conf"))?;
        writeln!(lc, "disable_mcl_levelgen = true")?;
    }

    let mut f = fs::File::create(mod_dir.join("init.lua"))?;
    writeln!(f, "-- Arnis world configuration")?;
    writeln!(
        f,
        "minetest.set_mapgen_setting(\"mg_name\", \"singlenode\", true)"
    )?;
    writeln!(f)?;
    writeln!(
        f,
        "local SPAWN = {{x={}, y={}, z={}}}",
        spawn_x, spawn_y, spawn_z
    )?;
    writeln!(f)?;
    writeln!(f, "-- Teleport player to our spawn after a short delay")?;
    writeln!(
        f,
        "-- (overrides game-specific spawn handlers like Mineclonia's)"
    )?;
    writeln!(f, "minetest.register_on_joinplayer(function(player)")?;
    writeln!(f, "    local name = player:get_player_name()")?;
    writeln!(f, "    local privs = minetest.get_player_privs(name)")?;
    writeln!(f, "    privs.fast = true")?;
    writeln!(f, "    privs.fly = true")?;
    writeln!(f, "    minetest.set_player_privs(name, privs)")?;
    writeln!(f, "    minetest.after(0.5, function()")?;
    writeln!(f, "        if player:is_player() then")?;
    writeln!(f, "            player:set_pos(SPAWN)")?;
    writeln!(f, "        end")?;
    writeln!(f, "    end)")?;
    writeln!(f, "end)")?;
    writeln!(f)?;
    writeln!(f, "minetest.register_on_respawnplayer(function(player)")?;
    writeln!(f, "    minetest.after(0.5, function()")?;
    writeln!(f, "        if player:is_player() then")?;
    writeln!(f, "            player:set_pos(SPAWN)")?;
    writeln!(f, "        end")?;
    writeln!(f, "    end)")?;
    writeln!(f, "    return true")?;
    writeln!(f, "end)")?;
    writeln!(f)?;

    writeln!(
        f,
        "-- Lazy fix-lighting: fix mapblock lighting around players as they move"
    )?;
    writeln!(
        f,
        "-- instead of fixing the entire world at once on first load."
    )?;
    writeln!(f, "local fixed_blocks = {{}}")?;
    writeln!(
        f,
        "local RADIUS = 3          -- fix 3 mapblocks in each direction"
    )?;
    writeln!(f, "local CHECK_INTERVAL = 0.3 -- seconds between checks")?;
    writeln!(
        f,
        "local MAX_FIXES = 8        -- max fix_light calls per check"
    )?;
    writeln!(f, "local timer = 0")?;
    writeln!(f)?;
    writeln!(f, "minetest.register_globalstep(function(dtime)")?;
    writeln!(f, "    timer = timer + dtime")?;
    writeln!(f, "    if timer < CHECK_INTERVAL then return end")?;
    writeln!(f, "    timer = 0")?;
    writeln!(f, "    local fixes = 0")?;
    writeln!(
        f,
        "    for _, player in ipairs(minetest.get_connected_players()) do"
    )?;
    writeln!(f, "        local pos = player:get_pos()")?;
    writeln!(f, "        local bx = math.floor(pos.x / 16)")?;
    writeln!(f, "        local by = math.floor(pos.y / 16)")?;
    writeln!(f, "        local bz = math.floor(pos.z / 16)")?;
    writeln!(f, "        for dx = -RADIUS, RADIUS do")?;
    writeln!(f, "            for dy = -RADIUS, RADIUS do")?;
    writeln!(f, "                for dz = -RADIUS, RADIUS do")?;
    writeln!(
        f,
        "                    local key = (bx+dx) .. \",\" .. (by+dy) .. \",\" .. (bz+dz)"
    )?;
    writeln!(f, "                    if not fixed_blocks[key] then")?;
    writeln!(f, "                        fixed_blocks[key] = true")?;
    writeln!(f, "                        local x1 = (bx+dx) * 16")?;
    writeln!(f, "                        local y1 = (by+dy) * 16")?;
    writeln!(f, "                        local z1 = (bz+dz) * 16")?;
    writeln!(f, "                        minetest.fix_light(")?;
    writeln!(f, "                            {{x=x1, y=y1, z=z1}},")?;
    writeln!(
        f,
        "                            {{x=x1+15, y=y1+15, z=z1+15}})"
    )?;
    writeln!(f, "                        fixes = fixes + 1")?;
    writeln!(
        f,
        "                        if fixes >= MAX_FIXES then return end"
    )?;
    writeln!(f, "                    end")?;
    writeln!(f, "                end")?;
    writeln!(f, "            end")?;
    writeln!(f, "        end")?;
    writeln!(f, "    end")?;
    writeln!(f, "end)")?;

    Ok(())
}

/// Serialize an air-only mapblock with full sunlight.
/// Used to place sky blocks above the world so the engine can propagate sun downward.
fn serialize_air_mapblock(game: LuantiGame) -> std::io::Result<Vec<u8>> {
    let air_name = to_luanti_node(AIR, game, None).name;

    let mut buf: Vec<u8> = Vec::with_capacity(4096);

    // flags: day_night_differs + generated (not underground)
    buf.push(0x02 | 0x08);
    // lighting_complete: upper 4 "nothing" bits set, boundary flags cleared
    buf.extend_from_slice(&0xF000u16.to_be_bytes());
    // timestamp
    buf.extend_from_slice(&0xFFFFFFFFu32.to_be_bytes());

    // name-id mapping: only air (ID 0)
    buf.push(0); // version
    buf.extend_from_slice(&1u16.to_be_bytes()); // 1 type
    buf.extend_from_slice(&0u16.to_be_bytes()); // id = 0
    buf.extend_from_slice(&(air_name.len() as u16).to_be_bytes());
    buf.extend_from_slice(air_name.as_bytes());

    // content_width, params_width
    buf.push(2);
    buf.push(2);

    // param0: all zeros (air = ID 0)
    buf.extend_from_slice(&[0u8; NODES_PER_BLOCK * 2]);
    // param1: full day-light for all air (day=15 in lower nibble, night=0 in upper)
    buf.extend_from_slice(&[15u8; NODES_PER_BLOCK]);
    // param2: all zeros
    buf.extend_from_slice(&[0u8; NODES_PER_BLOCK]);

    // Node metadata: empty
    buf.push(2);
    buf.extend_from_slice(&0u16.to_be_bytes());
    // Static objects: empty
    buf.push(0);
    buf.extend_from_slice(&0u16.to_be_bytes());
    // Node timers: empty
    buf.push(10);
    buf.extend_from_slice(&0u16.to_be_bytes());

    let compressed = zstd::bulk::compress(&buf, 3)?;
    let mut blob = Vec::with_capacity(1 + compressed.len());
    blob.push(MAP_FORMAT_VERSION);
    blob.extend_from_slice(&compressed);
    Ok(blob)
}

fn write_map_database(
    world: &WorldToModify,
    world_dir: &Path,
    game: LuantiGame,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let db_path = world_dir.join("map.sqlite");

    // Remove existing database if present
    if db_path.exists() {
        fs::remove_file(&db_path)?;
    }

    let conn = Connection::open(&db_path)?;

    // Optimize for bulk writes
    conn.execute_batch(
        "PRAGMA journal_mode = OFF;
         PRAGMA synchronous = OFF;
         PRAGMA locking_mode = EXCLUSIVE;",
    )?;

    conn.execute(
        "CREATE TABLE IF NOT EXISTS `blocks` (`pos` INT NOT NULL PRIMARY KEY, `data` BLOB)",
        [],
    )?;

    // Collect all mapblock positions and sections for parallel serialization
    let mut block_entries: Vec<(i32, i32, i32, &crate::world_editor::common::SectionToModify)> =
        Vec::new();

    // Track XZ extents and max Y to generate air mapblocks above
    let mut mb_min_x = i32::MAX;
    let mut mb_max_x = i32::MIN;
    let mut mb_min_z = i32::MAX;
    let mut mb_max_z = i32::MIN;
    let mut mb_max_y = i32::MIN;

    for (&(region_x, region_z), region) in &world.regions {
        for (&(chunk_x, chunk_z), chunk) in &region.chunks {
            for (&section_y, section) in &chunk.sections {
                // region_x * 32 + chunk_x = absolute chunk X = mapblock X
                // section_y (i8) = mapblock Y
                // Negate Z: Luanti Z+ = North, internal Z+ = South
                let mb_x = region_x * 32 + chunk_x;
                let orig_z = region_z * 32 + chunk_z;
                let mb_z = -orig_z - 1;
                let mb_y = section_y as i32;
                block_entries.push((mb_x, mb_y, mb_z, section));
                mb_min_x = mb_min_x.min(mb_x);
                mb_max_x = mb_max_x.max(mb_x);
                mb_min_z = mb_min_z.min(mb_z);
                mb_max_z = mb_max_z.max(mb_z);
                mb_max_y = mb_max_y.max(mb_y);
            }
        }
    }

    println!(
        "  Serializing {} mapblocks...",
        block_entries.len().to_string().bold()
    );

    let serialized: Vec<(i64, Vec<u8>)> = block_entries
        .par_iter()
        .map(|&(bx, by, bz, section)| serialize_mapblock(bx, by, bz, section, game))
        .collect::<std::io::Result<Vec<_>>>()?;

    // Air mapblocks above the world so the engine can propagate sunlight down.
    let air_blob = serialize_air_mapblock(game)?;
    let mut air_blocks: Vec<(i64, Vec<u8>)> = Vec::new();
    for extra_y in 1..=2 {
        let ay = mb_max_y + extra_y;
        for ax in mb_min_x..=mb_max_x {
            for az in mb_min_z..=mb_max_z {
                air_blocks.push((encode_block_pos(ax, ay, az), air_blob.clone()));
            }
        }
    }

    // Insert all serialized blocks into SQLite (must be sequential)
    conn.execute_batch("BEGIN TRANSACTION")?;
    {
        let mut stmt = conn.prepare("INSERT INTO `blocks` (`pos`, `data`) VALUES (?1, ?2)")?;
        for (pos, data) in &serialized {
            stmt.execute(rusqlite::params![pos, data])?;
        }
        for (pos, data) in &air_blocks {
            stmt.execute(rusqlite::params![pos, data])?;
        }
    }
    conn.execute_batch("COMMIT")?;

    println!(
        "  Wrote {} mapblocks to map.sqlite ({} content + {} air)",
        serialized.len() + air_blocks.len(),
        serialized.len(),
        air_blocks.len(),
    );

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encode_block_pos_origin() {
        assert_eq!(encode_block_pos(0, 0, 0), 0);
    }

    #[test]
    fn test_encode_block_pos_positive() {
        // pos = z * 0x1000000 + y * 0x1000 + x
        assert_eq!(encode_block_pos(1, 2, 3), 3 * 0x1000000 + 2 * 0x1000 + 1);
    }

    #[test]
    fn test_encode_block_pos_negative() {
        // Negative coordinates should work with signed arithmetic
        let pos = encode_block_pos(-1, -1, -1);
        assert_eq!(pos, -0x1000000_i64 - 0x1000_i64 - 1);
    }
}
