var map, rsidebar, lsidebar, drawControl, drawnItems = null;

// Where we keep the big list of proj defs from the server
var proj4defs = null;
// Where we keep the proj objects we are using in this session
var projdefs = { "4326": L.CRS.EPSG4326, "3857": L.CRS.EPSG3857 };
var currentproj = "3857";
var currentmouse = L.latLng(0, 0);

/*
**
**  override L.Rectangle 
**  to fire an event after setting
**
**  the base parent object L.Path
**  inherits from L.Evented
**
**  ensures bbox box is always
**  the topmost SVG feature
**
*/
L.Rectangle.prototype.setBounds = function (latLngBounds) {

    this.setLatLngs(this._boundsToLatLngs(latLngBounds));
    this.fire('bounds-set');
}


var FormatSniffer = (function () {  // execute immediately

    'use strict';

    /*
    **
    **  constructor
    **
    */
    var FormatSniffer = function (options) {

        options || (options = {});

        if (!this || !(this instanceof FormatSniffer)) {
            return new FormatSniffer(options);
        }


        this.regExes = {
            ogrinfoExtent: /Extent\:\s\((.*)\)/,
            bbox: /^\(([\s|\-|0-9]*\.[0-9]*,[\s|\-|0-9]*\.[0-9]*,[\s|\-|0-9]*\.[0-9]*,[\s|\-|0-9]*\.[0-9|\s]*)\)$/
        };
        this.data = options.data || "";
        this.parse_type = null;
    };

    /*
    **
    **  functions
    **
    */
    FormatSniffer.prototype.sniff = function () {
        return this._sniffFormat();
    };

    FormatSniffer.prototype._is_ogrinfo = function () {
        var match = this.regExes.ogrinfoExtent.exec(this.data.trim());
        var extent = [];
        if (match) {
            var pairs = match[1].split(") - (");
            for (var indx = 0; indx < pairs.length; indx++) {
                var coords = pairs[indx].trim().split(",");
                extent = (extent.concat([parseFloat(coords[0].trim()), parseFloat(coords[1].trim())]));
            }
        }
        this.parse_type = "ogrinfo";
        return extent;
    };

    FormatSniffer.prototype._is_normal_bbox = function () {
        var match = this.regExes.bbox.exec(this.data.trim());
        var extent = [];
        if (match) {
            var bbox = match[1].split(",");
            for (var indx = 0; indx < bbox.length; indx++) {
                var coord = bbox[indx].trim();
                extent = (extent.concat([parseFloat(coord)]));
            }
        }
        this.parse_type = "bbox";
        return extent;
    };

    FormatSniffer.prototype._is_geojson = function () {
        try {
            // try JSON
            var json = JSON.parse(this.data);

            // try GeoJSON
            var parsed_data = new L.geoJson(json)

        } catch (err) {

            return null;

        }

        this.parse_type = "geojson";
        return parsed_data;
    };

    FormatSniffer.prototype._is_wkt = function () {
        if (this.data === "") {
            throw new Error("empty -- nothing to parse");
        }

        try {
            var parsed_data = new Wkt.Wkt(this.data);
        } catch (err) {
            return null;
        }

        this.parse_type = "wkt";
        return parsed_data;
    };

    FormatSniffer.prototype._sniffFormat = function () {

        var parsed_data = null;
        var fail = false;
        try {
            var next = true;

            // try ogrinfo
            parsed_data = this._is_ogrinfo()
            if (parsed_data.length > 0) {
                next = false;
            }

            // try normal bbox 
            if (next) {
                parsed_data = this._is_normal_bbox();
                if (parsed_data.length > 0) next = false;
            }

            // try GeoJSON
            if (next) {
                parsed_data = this._is_geojson();
                if (parsed_data) next = false;
            }

            // try WKT
            if (next) {
                parsed_data = this._is_wkt();
                if (parsed_data) next = false;
            }

            // no matches, throw error
            if (next) {
                fail = true;
                /* 
                **  sorry, this block needs to be left aligned
                **  to make the alert more readable
                **  which means, we probably shouldn't use alerts ;-)
                */
                throw {
                    "name": "NoTypeMatchError",
                    "message": "The data is not a recognized format:\n \
1. ogrinfo extent output\n \
2. bbox as (xMin,yMin,xMax,yMax )\n \
3. GeoJSON\n \
4. WKT\n\n "
                }
            }


        } catch (err) {

            alert("Your paste is not parsable:\n" + err.message);
            fail = true;

        }

        // delegate to format handler
        if (!fail) {

            this._formatHandler[this.parse_type].call(this._formatHandler, parsed_data);

        }

        return (fail ? false : true);
    };


    /*
    **  an object with functions as property names.
    **  if we need to add another format
    **  we can do so here as a property name
    **  to enforce reusability
    **
    **  to add different formats as L.FeatureGroup layer 
    **  so they work with L.Draw edit and delete options
    **  we fake passing event information
    **  and triggering draw:created for L.Draw
    */
    FormatSniffer.prototype._formatHandler = {


        // coerce event objects to work with L.Draw types
        coerce: function (lyr, type_obj) {

            var event_obj = {
                layer: lyr,
                layerType: null,
            }

            // coerce to L.Draw types
            if (/point/i.test(type_obj)) {
                event_obj.layerType = "marker";
            }
            else if (/linestring/i.test(type_obj)) {
                event_obj.layerType = "polyline";
            }
            else if (/polygon/i.test(type_obj)) {
                event_obj.layerType = "polygon";
            }

            return event_obj;

        },

        reduce_layers: function (lyr) {
            var lyr_parts = [];
            if (typeof lyr['getLayers'] === 'undefined') {
                return [lyr];
            }
            else {
                var all_layers = lyr.getLayers();
                for (var i = 0; i < all_layers.length; i++) {
                    lyr_parts = lyr_parts.concat(this.reduce_layers(all_layers[i]));
                }
            }
            return lyr_parts;
        },

        get_leaflet_bounds: function (data) {
            /*
            **  data comes in an extent ( xMin,yMin,xMax,yMax )
            **  we need to swap lat/lng positions
            **  because leaflet likes it hard
            */
            var sw = [data[1], data[0]];
            var ne = [data[3], data[2]];
            return new L.LatLngBounds(sw, ne);
        },

        wkt: function (data) {
            var wkt_layer = data.construct[data.type].call(data);
            var all_layers = this.reduce_layers(wkt_layer);
            for (var indx = 0; indx < all_layers.length; indx++) {
                var lyr = all_layers[indx];
                var evt = this.coerce(lyr, data.type);

                // call L.Draw.Feature.prototype._fireCreatedEvent
                map.fire('draw:created', evt);
            }

        },

        geojson: function (geojson_layer) {
            var all_layers = this.reduce_layers(geojson_layer);
            for (var indx = 0; indx < all_layers.length; indx++) {
                var lyr = all_layers[indx];

                var geom_type = geojson_layer.getLayers()[0].feature.geometry.type;
                var evt = this.coerce(lyr, geom_type);

                // call L.Draw.Feature.prototype._fireCreatedEvent
                map.fire('draw:created', evt);
            }
        },

        ogrinfo: function (data) {
            var lBounds = this.get_leaflet_bounds(data);
            // create a rectangle layer
            var lyr = new L.Rectangle(lBounds);
            var evt = this.coerce(lyr, 'polygon');

            // call L.Draw.Feature.prototype._fireCreatedEvent
            map.fire('draw:created', evt);
        },

        bbox: function (data) {
            var lBounds = this.get_leaflet_bounds(data);
            // create a rectangle layer
            var lyr = new L.Rectangle(lBounds);
            var evt = this.coerce(lyr, 'polygon');

            // call L.Draw.Feature.prototype._fireCreatedEvent
            map.fire('draw:created', evt);
        }
    };

    return FormatSniffer; // return class def

})(); // end FormatSniffer


function addLayer(layer, name, title, zIndex, on) {
    if (on) {
        layer.setZIndex(zIndex).addTo(map);
    } else {
        layer.setZIndex(zIndex);
    }
    // Create a simple layer switcher that toggles layers on and off.
    var ui = document.getElementById('map-ui');
    var item = document.createElement('li');
    var link = document.createElement('a');
    link.href = '#';
    if (on) {
        link.className = 'enabled';
    } else {
        link.className = '';
    }
    link.innerHTML = name;
    link.title = title;
    link.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();

        if (map.hasLayer(layer)) {
            map.removeLayer(layer);
            this.className = '';
        } else {
            map.addLayer(layer);
            this.className = 'enabled';
        }
    };
    item.appendChild(link);
    ui.appendChild(item);
};

function formatBounds(bounds, proj) {
    var gdal = $("input[name='gdal-checkbox']").prop('checked');
    var lngLat = $("input[name='coord-order']").prop('checked');

    var formattedBounds = '';
    var southwest = bounds.getSouthWest();
    var northeast = bounds.getNorthEast();
    var xmin = 0;
    var ymin = 0;
    var xmax = 0;
    var ymax = 0;
    if (proj == '4326') {
        xmin = southwest.lng.toFixed(6);
        ymin = southwest.lat.toFixed(6);
        xmax = northeast.lng.toFixed(6);
        ymax = northeast.lat.toFixed(6);
    } else {
        var proj_to_use = null;
        if (typeof (projdefs[proj]) !== 'undefined') {
            // we have it already, then grab it and use it...
            proj_to_use = projdefs[proj];
        } else {
            // We have not used this one yet... make it and store it...
            projdefs[proj] = new L.Proj.CRS(proj, proj4defs[proj][1]);
            proj_to_use = projdefs[proj];
        }
        southwest = proj_to_use.project(southwest)
        northeast = proj_to_use.project(northeast)
        xmin = southwest.x.toFixed(4);
        ymin = southwest.y.toFixed(4);
        xmax = northeast.x.toFixed(4);
        ymax = northeast.y.toFixed(4);
    }

    if (gdal) {
        if (lngLat) {
            formattedBounds = xmin + ',' + ymin + ',' + xmax + ',' + ymax;
        } else {
            formattedBounds = ymin + ',' + xmin + ',' + ymax + ',' + xmax;
        }
    } else {
        if (lngLat) {
            formattedBounds = xmin + ' ' + ymin + ' ' + xmax + ' ' + ymax;
        } else {
            formattedBounds = ymin + ' ' + xmin + ' ' + ymax + ' ' + xmax;
        }
    }
    return formattedBounds
}

function formatTile(point, zoom) {
    var xTile = Math.floor((point.lng + 180) / 360 * Math.pow(2, zoom));
    var yTile = Math.floor((1 - Math.log(Math.tan(point.lat * Math.PI / 180) + 1 / Math.cos(point.lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom));
    return xTile.toString() + ',' + yTile.toString();
}

function formatPoint(point, proj) {
    var gdal = $("input[name='gdal-checkbox']").prop('checked');
    var lngLat = $("input[name='coord-order']").prop('checked');

    var formattedPoint = '';
    if (proj == '4326') {
        x = point.lng.toFixed(6);
        y = point.lat.toFixed(6);
    } else {
        var proj_to_use = null;
        if (typeof (projdefs[proj]) !== 'undefined') {
            // we have it already, then grab it and use it...
            proj_to_use = projdefs[proj];
        } else {
            // We have not used this one yet... make it and store it...
            projdefs[proj] = new L.Proj.CRS(proj, proj4defs[proj][1]);
            proj_to_use = projdefs[proj];
        }
        point = proj_to_use.project(point)
        x = point.x.toFixed(4);
        y = point.y.toFixed(4);
    }
    if (gdal) {
        if (lngLat) {
            formattedBounds = x + ',' + y;
        } else {
            formattedBounds = y + ',' + x;
        }
    } else {
        if (lngLat) {
            formattedBounds = x + ' ' + y;
        } else {
            formattedBounds = y + ' ' + x;
        }
    }
    return formattedPoint
}

function validateStringAsBounds(bounds) {
    var splitBounds = bounds ? bounds.split(',') : null;
    return ((splitBounds !== null) &&
        (splitBounds.length == 4) &&
        ((-90.0 <= parseFloat(splitBounds[0]) <= 90.0) &&
            (-180.0 <= parseFloat(splitBounds[1]) <= 180.0) &&
            (-90.0 <= parseFloat(splitBounds[2]) <= 90.0) &&
            (-180.0 <= parseFloat(splitBounds[3]) <= 180.0)) &&
        (parseFloat(splitBounds[0]) < parseFloat(splitBounds[2]) &&
            parseFloat(splitBounds[1]) < parseFloat(splitBounds[3])))
}

$(document).ready(function () {
    /* 
    **
    **  make sure all textarea inputs
    **  are selected once they are clicked
    **  because some people might not 
    **  have flash enabled or installed
    **  and yes...
    **  there's a fucking Flash movie floating 
    **  on top of your DOM
    **
    */

    // init the projection input box as it is used to format the initial values
    $('input[type="textarea"]').on('click', function (evt) { this.select() });
    $("#projection").val(currentproj);

    // Initialize map
    map = L.map('map', { zoomControl: false }).setView([50.114768, 8.687322], 4);

    // Define available tile themes
    var tileThemes = {
        'osm': {
            url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            options: {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 19
            }
        },
        'esri-imagery': {
            url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            options: {
                attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
                maxZoom: 18
            }
        },
        'opentopomap': {
            url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
            options: {
                attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)',
                maxZoom: 17
            }
        },
        'stadia-bright': {
            url: 'https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}.{ext}',
            options: {
                minZoom: 0,
                maxZoom: 19,
                attribution: '&copy; <a href="https://www.stadiamaps.com/" target="_blank">Stadia Maps</a> &copy; <a href="https://openmaptiles.org/" target="_blank">OpenMapTiles</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                ext: 'png'
            }
        },
        'stadia-dark': {
            url: 'https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}.{ext}',
            options: {
                minZoom: 0,
                maxZoom: 19,
                attribution: '&copy; <a href="https://www.stadiamaps.com/" target="_blank">Stadia Maps</a> &copy; <a href="https://openmaptiles.org/" target="_blank">OpenMapTiles</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                ext: 'png'
            }
        },
        'openfreemap-liberty': {
            type: 'vector',
            style: 'https://tiles.openfreemap.org/styles/liberty',
            attribution: '&copy; <a href="https://openfreemap.org" target="_blank">OpenFreeMap</a> &copy; <a href="https://www.openmaptiles.org/" target="_blank">OpenMapTiles</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }
    };

    // Global variable to store current tile layer
    var currentTileLayer = null;

    // Function to change tile theme with automatic HTTP fallback
    function changeTileTheme(themeKey) {
        // Remove current tile layer if it exists
        if (currentTileLayer) {
            map.removeLayer(currentTileLayer);
        }

        // Get the theme configuration
        var theme = tileThemes[themeKey];
        if (theme) {
            if (theme.type === 'vector') {
                // Fall back to OSM raster if MapLibre plugin failed to load
                if (typeof L.maplibreGL !== 'function') {
                    console.warn('MapLibre GL plugin unavailable, falling back to OSM raster');
                    changeTileTheme('osm');
                    return;
                }
                currentTileLayer = L.maplibreGL({
                    style: theme.style,
                    attributionControl: { customAttribution: theme.attribution },
                    pixelRatio: window.devicePixelRatio || 1
                });
                currentTileLayer.addTo(map);
            } else {
                currentTileLayer = L.tileLayer(theme.url, theme.options);

                // Add automatic HTTP fallback for HTTPS failures
                var failureCount = 0;
                currentTileLayer.on('tileerror', function(error) {
                    failureCount++;

                    // After a few failures, try HTTP fallback
                    if (failureCount >= 6 && !this._httpFallbackAttempted && theme.url.startsWith('https://')) {
                        console.log('HTTPS tile loading failed, attempting HTTP fallback for', themeKey);
                        this._httpFallbackAttempted = true;

                        // Create HTTP version of the URL
                        var httpUrl = theme.url.replace('https://', 'http://');

                        // Remove the failed HTTPS layer
                        map.removeLayer(this);

                        // Create new layer with HTTP URL
                        var httpLayer = L.tileLayer(httpUrl, theme.options);
                        httpLayer._httpFallbackAttempted = true;
                        httpLayer.addTo(map);
                        currentTileLayer = httpLayer;
                    }
                });

                currentTileLayer.addTo(map);
            }

            // Save preference to localStorage
            localStorage.setItem('selectedTileTheme', themeKey);
        }
    }

    // Load saved theme or default to OSM
    var savedTheme = localStorage.getItem('selectedTileTheme') || 'osm';
    changeTileTheme(savedTheme);

    // World overlay state
    var worldOverlay = null;
    var worldOverlayData = null;
    var worldOverlayEnabled = false;
    var worldPreviewAvailable = false;
    var sliderControl = null;
    var worldOverlayHiddenForEdit = false; // Track if we hid the overlay for edit/delete mode

    // Create the opacity slider as a proper Leaflet control
    var SliderControl = L.Control.extend({
        options: { position: 'topleft' },
        onAdd: function(map) {
            var container = L.DomUtil.create('div', 'leaflet-bar world-preview-slider-container');
            container.id = 'world-preview-slider-container';
            container.style.display = 'none';

            var slider = L.DomUtil.create('input', 'world-preview-slider', container);
            slider.type = 'range';
            slider.min = '0';
            slider.max = '100';
            slider.value = '50';
            slider.id = 'world-preview-opacity';
            slider.title = 'Overlay Opacity';

            L.DomEvent.on(slider, 'input', function(e) {
                if (worldOverlay) {
                    worldOverlay.setOpacity(e.target.value / 100);
                }
            });

            // Prevent all map interactions
            L.DomEvent.disableClickPropagation(container);
            L.DomEvent.disableScrollPropagation(container);
            L.DomEvent.on(container, 'mousedown', L.DomEvent.stopPropagation);
            L.DomEvent.on(container, 'touchstart', L.DomEvent.stopPropagation);
            L.DomEvent.on(slider, 'mousedown', L.DomEvent.stopPropagation);
            L.DomEvent.on(slider, 'touchstart', L.DomEvent.stopPropagation);

            return container;
        }
    });

    // Function to add world preview button to the draw control's edit toolbar
    function addWorldPreviewToEditToolbar() {
        // Find the edit toolbar (contains Edit layers and Delete layers buttons)
        var editToolbar = document.querySelector('.leaflet-draw-toolbar:not(.leaflet-draw-toolbar-top)');
        if (!editToolbar) {
            // Try finding by the edit/delete buttons
            var deleteBtn = document.querySelector('.leaflet-draw-edit-remove');
            if (deleteBtn) {
                editToolbar = deleteBtn.parentElement;
            }
        }

        if (editToolbar) {
            // Create the preview button
            var toggleBtn = document.createElement('a');
            toggleBtn.className = 'leaflet-draw-edit-preview disabled';
            toggleBtn.href = '#';
            toggleBtn.title = 'Show World Preview (not available yet)';
            toggleBtn.id = 'world-preview-btn';

            toggleBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (worldPreviewAvailable) {
                    toggleWorldOverlay();
                }
            });

            editToolbar.appendChild(toggleBtn);

            // Add the slider control to the map
            sliderControl = new SliderControl();
            map.addControl(sliderControl);
        }
    }

    // Toggle world overlay function
    function toggleWorldOverlay() {
        if (!worldPreviewAvailable || !worldOverlayData) return;

        worldOverlayEnabled = !worldOverlayEnabled;
        var btn = document.getElementById('world-preview-btn');
        var sliderContainer = document.getElementById('world-preview-slider-container');

        if (worldOverlayEnabled) {
            // Show overlay
            var data = worldOverlayData;
            var bounds = L.latLngBounds(
                [data.min_lat, data.min_lon],
                [data.max_lat, data.max_lon]
            );

            if (worldOverlay) {
                map.removeLayer(worldOverlay);
            }

            var opacity = document.getElementById('world-preview-opacity');
            var opacityValue = opacity ? opacity.value / 100 : 0.5;

            worldOverlay = L.imageOverlay(data.image_base64, bounds, {
                opacity: opacityValue,
                interactive: false,
                zIndex: 500
            });
            worldOverlay.addTo(map);

            if (btn) {
                btn.classList.add('active');
                btn.title = 'Hide World Preview';
            }
            if (sliderContainer) {
                sliderContainer.style.display = 'block';
            }
        } else {
            // Hide overlay
            if (worldOverlay) {
                map.removeLayer(worldOverlay);
                worldOverlay = null;
            }
            if (btn) {
                btn.classList.remove('active');
                btn.title = 'Show World Preview';
            }
            if (sliderContainer) {
                sliderContainer.style.display = 'none';
            }
        }
    }

    // Enable the preview button when data is available
    function enableWorldPreview(data) {
        // Skip world preview when rotation is active — the preview image covers
        // the expanded post-rotation MC bbox but the geo bounds are pre-rotation,
        // so the image would be squeezed incorrectly onto the map.
        if (Math.abs(window._rotationAngle || 0) >= 0.001) {
            return;
        }
        worldOverlayData = data;
        worldPreviewAvailable = true;
        var btn = document.getElementById('world-preview-btn');
        if (btn) {
            btn.classList.remove('disabled');
            btn.title = 'Show World Preview';
        }
    }

    // Disable and reset preview (when world changes)
    function disableWorldPreview() {
        worldPreviewAvailable = false;
        worldOverlayData = null;
        worldOverlayEnabled = false;

        if (worldOverlay) {
            map.removeLayer(worldOverlay);
            worldOverlay = null;
        }

        var btn = document.getElementById('world-preview-btn');
        var sliderContainer = document.getElementById('world-preview-slider-container');
        if (btn) {
            btn.classList.add('disabled');
            btn.classList.remove('active');
            btn.title = 'Show World Preview (not available yet)';
        }
        if (sliderContainer) {
            sliderContainer.style.display = 'none';
        }
    }

    // Temporarily hide the overlay (for edit/delete mode)
    function hideWorldOverlayTemporarily() {
        if (worldOverlay && worldOverlayEnabled) {
            worldOverlayHiddenForEdit = true;
            map.removeLayer(worldOverlay);
        }
        // Also visually disable the preview button during edit/delete mode
        var btn = document.getElementById('world-preview-btn');
        if (btn) {
            btn.classList.add('editing-mode');
        }
    }

    // Restore the overlay after edit/delete mode ends
    function restoreWorldOverlay() {
        if (worldOverlayHiddenForEdit && worldOverlay && worldOverlayEnabled) {
            worldOverlay.addTo(map);
            worldOverlayHiddenForEdit = false;
        }
        // Re-enable the preview button
        var btn = document.getElementById('world-preview-btn');
        if (btn) {
            btn.classList.remove('editing-mode');
        }
    }


    // ========== Context Menu for Coordinate Copying ==========
    var contextMenuElement = null;

    // Create the context menu element
    function createContextMenu() {
        if (contextMenuElement) return contextMenuElement;

        contextMenuElement = document.createElement('div');
        contextMenuElement.className = 'coordinate-context-menu';
        contextMenuElement.style.display = 'none';
        contextMenuElement.innerHTML = `
            <div class="coordinate-context-menu-item" id="copy-coords-item">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                <span id="copy-coords-text">Copy coordinates</span>
            </div>
        `;
        document.body.appendChild(contextMenuElement);

        // Handle click on the copy coordinates item
        var copyItem = contextMenuElement.querySelector('#copy-coords-item');
        copyItem.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            copyMinecraftCoordinates();
            hideContextMenu();
        });

        return contextMenuElement;
    }

    // Show context menu at position
    function showContextMenu(x, y, latLng) {
        if (!worldPreviewAvailable || !worldOverlayData) return;

        var menu = createContextMenu();

        // Position the menu, ensuring it stays within viewport
        var menuWidth = 180;
        var menuHeight = 40;
        var viewportWidth = window.innerWidth;
        var viewportHeight = window.innerHeight;

        var posX = x;
        var posY = y;

        // Adjust if menu would go off-screen
        if (x + menuWidth > viewportWidth) {
            posX = viewportWidth - menuWidth - 10;
        }
        if (y + menuHeight > viewportHeight) {
            posY = viewportHeight - menuHeight - 10;
        }

        menu.style.left = posX + 'px';
        menu.style.top = posY + 'px';
        menu.style.display = 'block';

        // Store the latLng for copying
        menu.dataset.lat = latLng.lat;
        menu.dataset.lng = latLng.lng;
    }

    // Hide context menu
    function hideContextMenu() {
        if (contextMenuElement) {
            contextMenuElement.style.display = 'none';
        }
    }

    // Calculate Minecraft coordinates from lat/lng
    function calculateMinecraftCoords(lat, lng) {
        if (!worldOverlayData) return null;

        var data = worldOverlayData;

        // Check if Minecraft coordinate bounds are available (not all zeros)
        if (data.min_mc_x === 0 && data.max_mc_x === 0 && 
            data.min_mc_z === 0 && data.max_mc_z === 0) {
            return null;
        }

        // Calculate the relative position within the geo bounds (0 to 1)
        // Note: Latitude increases northward, but Minecraft Z increases southward
        var relX = (lng - data.min_lon) / (data.max_lon - data.min_lon);
        var relZ = (data.max_lat - lat) / (data.max_lat - data.min_lat);

        // Clamp to 0-1 range
        relX = Math.max(0, Math.min(1, relX));
        relZ = Math.max(0, Math.min(1, relZ));

        // Calculate Minecraft X and Z coordinates
        var mcX = Math.round(data.min_mc_x + relX * (data.max_mc_x - data.min_mc_x));
        var mcZ = Math.round(data.min_mc_z + relZ * (data.max_mc_z - data.min_mc_z));

        // Default Y coordinate (ground level, typically around 64-70)
        var mcY = 100;

        return { x: mcX, y: mcY, z: mcZ };
    }

    // Copy Minecraft coordinates to clipboard
    function copyMinecraftCoordinates() {
        if (!contextMenuElement) return;

        var lat = parseFloat(contextMenuElement.dataset.lat);
        var lng = parseFloat(contextMenuElement.dataset.lng);

        var coords = calculateMinecraftCoords(lat, lng);
        if (!coords) return;

        var tpCommand = '/tp ' + coords.x + ' ' + coords.y + ' ' + coords.z;

        // Copy to clipboard using modern API with fallback
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(tpCommand).catch(function(err) {
                // Fallback for clipboard API failure
                fallbackCopyToClipboard(tpCommand);
            });
        } else {
            // Fallback for older browsers
            fallbackCopyToClipboard(tpCommand);
        }
    }

    // Fallback clipboard copy method for older browsers
    function fallbackCopyToClipboard(text) {
        var textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        textArea.style.top = '-9999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            document.execCommand('copy');
        } catch (err) {
            console.error('Failed to copy coordinates:', err);
        }

        document.body.removeChild(textArea);
    }

    // Check if Minecraft coordinate bounds are available
    function hasMinecraftCoords() {
        if (!worldOverlayData) return false;
        var data = worldOverlayData;
        return !(data.min_mc_x === 0 && data.max_mc_x === 0 && 
                 data.min_mc_z === 0 && data.max_mc_z === 0);
    }

    // Handle right-click on the map
    map.on('contextmenu', function(e) {
        // Only show context menu if world preview is available and has Minecraft coords
        if (worldPreviewAvailable && worldOverlayData && hasMinecraftCoords()) {
            // Check if the click is within the world bounds
            var data = worldOverlayData;
            var lat = e.latlng.lat;
            var lng = e.latlng.lng;

            if (lat >= data.min_lat && lat <= data.max_lat &&
                lng >= data.min_lon && lng <= data.max_lon) {
                showContextMenu(e.originalEvent.clientX, e.originalEvent.clientY, e.latlng);
            }
        }
    });

    // Hide context menu on any click or map interaction
    document.addEventListener('click', function(e) {
        if (contextMenuElement && !contextMenuElement.contains(e.target)) {
            hideContextMenu();
        }
    });

    map.on('movestart', hideContextMenu);
    map.on('zoomstart', hideContextMenu);
    // ========== End Context Menu ==========

    // Listen for messages from parent window
    window.addEventListener('message', function(event) {
        if (event.data && event.data.type === 'changeTileTheme') {
            changeTileTheme(event.data.theme);
        }

        // Handle world preview data ready (after generation completes)
        if (event.data && event.data.type === 'worldPreviewReady') {
            enableWorldPreview(event.data.data);

            // Auto-enable the overlay when generation completes
            if (!worldOverlayEnabled) {
                toggleWorldOverlay();
            }
        }

        // Handle existing world map load (zoom to location and auto-enable)
        if (event.data && event.data.type === 'loadExistingWorldMap') {
            var data = event.data.data;
            enableWorldPreview(data);

            // Calculate bounds and zoom to them
            var bounds = L.latLngBounds(
                [data.min_lat, data.min_lon],
                [data.max_lat, data.max_lon]
            );
            map.fitBounds(bounds, { padding: [50, 50] });

            // Auto-enable the overlay
            if (!worldOverlayEnabled) {
                toggleWorldOverlay();
            }
        }

        // Handle world changed (disable preview)
        if (event.data && event.data.type === 'worldChanged') {
            disableWorldPreview();
        }

        // Handle rotation preview angle update (store it for preview-skip logic)
        if (event.data && event.data.type === 'rotatePreview') {
            var angle = event.data.angle || 0;
            window._rotationAngle = angle;
            // Clear the world preview since it won't align at a different angle
            if (worldOverlayEnabled && Math.abs(angle) >= 0.001) {
                disableWorldPreview();
            }
        }

    });

    // Set the dropdown value in parent window if it exists
    if (window.parent && window.parent.document) {
        var dropdown = window.parent.document.getElementById('tile-theme-select');
        if (dropdown) {
            dropdown.value = savedTheme;
        }
    }

    rsidebar = L.control.sidebar('rsidebar', {
        position: 'right',
        closeButton: true
    });
    rsidebar.on("sidebar-show", function (e) {
        $("#map .leaflet-tile-loaded").addClass("blurred");
    });
    rsidebar.on("sidebar-hide", function (e) {
        $('#map .leaflet-tile-loaded').removeClass('blurred');
        $('#map .leaflet-tile-loaded').addClass('unblurred');
        setTimeout(function () {
            $('#map .leaflet-tile-loaded').removeClass('unblurred');
        }, 7000);
    });

    map.addControl(rsidebar);

    lsidebar = L.control.sidebar('lsidebar', {
        position: 'left'
    });

    map.addControl(lsidebar);

    // Add in a crosshair for the map
    var crosshairIcon = L.icon({
        iconUrl: 'images/crosshair.png',
        iconSize: [20, 20], // size of the icon
        iconAnchor: [10, 10], // point of the icon which will correspond to marker's location
    });
    crosshair = new L.marker(map.getCenter(), { icon: crosshairIcon, interactive: false });
    crosshair.addTo(map);

    // Override default tooltips
    L.drawLocal = L.drawLocal || {};
    L.drawLocal.draw = L.drawLocal.draw || {};
    L.drawLocal.draw.toolbar = L.drawLocal.draw.toolbar || {};
    L.drawLocal.draw.toolbar.buttons = L.drawLocal.draw.toolbar.buttons || {};
    L.drawLocal.draw.toolbar.buttons.rectangle = 'Choose area';
    L.drawLocal.draw.toolbar.buttons.marker = 'Set spawnpoint';

    // Initialize the FeatureGroup to store editable layers
    drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);

    // Custom icon for drawn markers
    var customMarkerIcon = L.icon({
        iconUrl: 'images/marker-icon.png',
        iconSize: [20, 20],
        iconAnchor: [10, 10],
        popupAnchor: [0, -10]
    });

    // Calculate geographic angle between two lat/lng points (in degrees)
    function calculateAngleGeo(latlng1, latlng2) {
        var lat1 = latlng1.lat * Math.PI / 180;
        var lat2 = latlng2.lat * Math.PI / 180;
        var dx = (latlng2.lng - latlng1.lng) * Math.cos((lat1 + lat2) / 2);
        var dy = latlng2.lat - latlng1.lat;
        var radians = Math.atan2(dy, dx);
        var degrees = radians * (180 / Math.PI);
        if (degrees < 0) degrees += 360;
        return degrees;
    }

    // Calculate the signed rotation needed to align to the nearest cardinal axis (0, 90, 180, 270)
    // Positive = clockwise on map, negative = counterclockwise
    function getRotationToNearestAxis(angle) {
        var axes = [0, 90, 180, 270, 360];
        var bestDiff = 360;
        for (var i = 0; i < axes.length; i++) {
            var diff = angle - axes[i];
            if (Math.abs(diff) < Math.abs(bestDiff)) bestDiff = diff;
        }
        return bestDiff;
    }

    drawControl = new L.Control.Draw({
        edit: {
            featureGroup: drawnItems
        },
        draw: {
            rectangle: {
                shapeOptions: {
                    color: '#fe57a1',
                    opacity: 0.6,
                    weight: 3,
                    fillColor: '#fe57a1',
                    fillOpacity: 0.1,
                    dashArray: '10, 10',
                    lineCap: 'round',
                    lineJoin: 'round'
                },
                repeatMode: false
            },
            polyline: false,
            polygon: false,
            circle: false,
            circlemarker: false,
            marker: {
                icon: customMarkerIcon
            }
        }
    });
    map.addControl(drawControl);

    // ========== Custom Angle Line Tool ==========
    // A simple 2-click tool: click start point, click end point, done.
    // Uses a transparent overlay to capture clicks even on top of drawn layers.
    var _angleLine = null;
    var _angleStartLatLng = null;
    var _angleToolActive = false;
    var _angleToolBtn = null;
    var _angleOverlay = null;        // transparent click-capture div

    function startAngleTool() {
        stopAngleTool();
        _angleToolActive = true;

        // Create a transparent overlay over the map to capture all clicks
        // (otherwise clicks on the bbox rectangle get swallowed by the layer)
        _angleOverlay = document.createElement('div');
        _angleOverlay.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;z-index:1000;cursor:crosshair;';
        map.getContainer().appendChild(_angleOverlay);

        _angleOverlay.addEventListener('click', _onAngleOverlayClick);
        _angleOverlay.addEventListener('mousemove', _onAngleOverlayMouseMove);
    }

    function stopAngleTool() {
        _angleToolActive = false;
        _angleStartLatLng = null;
        if (_angleOverlay) {
            _angleOverlay.removeEventListener('click', _onAngleOverlayClick);
            _angleOverlay.removeEventListener('mousemove', _onAngleOverlayMouseMove);
            _angleOverlay.parentNode && _angleOverlay.parentNode.removeChild(_angleOverlay);
            _angleOverlay = null;
        }
        if (_angleLine) {
            map.removeLayer(_angleLine);
            _angleLine = null;
        }
        if (_angleToolBtn) {
            L.DomUtil.removeClass(_angleToolBtn, 'leaflet-draw-toolbar-button-enabled');
        }
    }

    function _overlayEventToLatLng(e) {
        var rect = map.getContainer().getBoundingClientRect();
        var point = L.point(e.clientX - rect.left, e.clientY - rect.top);
        return map.containerPointToLatLng(point);
    }

    function _onAngleOverlayClick(e) {
        var latlng = _overlayEventToLatLng(e);

        if (!_angleStartLatLng) {
            // First click — place start point
            _angleStartLatLng = latlng;
            _angleLine = L.polyline([_angleStartLatLng, _angleStartLatLng], {
                color: '#00aaff',
                weight: 3,
                dashArray: '5, 5'
            }).addTo(map);
        } else {
            // Second click — finish
            _angleLine.setLatLngs([_angleStartLatLng, latlng]);

            var angle = calculateAngleGeo(_angleStartLatLng, latlng);
            var rotation = getRotationToNearestAxis(angle);
            var rotationValue = parseFloat(rotation.toFixed(2));

            window.parent.postMessage({
                type: 'angleMeasured',
                angle: rotationValue
            }, '*');

            showRotationToast('Rotation angle set to ' + rotationValue + '\u00B0 (see settings)');

            // Keep the line visible briefly, then remove
            var lineRef = _angleLine;
            _angleLine = null;
            setTimeout(function() {
                if (lineRef) map.removeLayer(lineRef);
            }, 1500);

            stopAngleTool();
        }
    }

    function _onAngleOverlayMouseMove(e) {
        if (_angleLine && _angleStartLatLng) {
            _angleLine.setLatLngs([_angleStartLatLng, _overlayEventToLatLng(e)]);
        }
    }

    // Inject the angle tool button into the top draw toolbar (alongside rectangle & marker)
    (function addAngleToolButton() {
        var drawToolbar = document.querySelector('.leaflet-draw-toolbar.leaflet-draw-toolbar-top');
        if (!drawToolbar) return;

        var btn = L.DomUtil.create('a', 'leaflet-draw-draw-polyline');
        btn.href = '#';
        btn.title = 'Set rotation angle';

        L.DomEvent
            .on(btn, 'click', L.DomEvent.stopPropagation)
            .on(btn, 'mousedown', L.DomEvent.stopPropagation)
            .on(btn, 'dblclick', L.DomEvent.stopPropagation)
            .on(btn, 'click', L.DomEvent.preventDefault)
            .on(btn, 'click', function() {
                if (_angleToolActive) {
                    stopAngleTool();
                } else {
                    startAngleTool();
                    L.DomUtil.addClass(btn, 'leaflet-draw-toolbar-button-enabled');
                }
            });

        _angleToolBtn = btn;

        // Insert before the marker (spawn) button so it's: rectangle | angle | marker
        var markerBtn = drawToolbar.querySelector('.leaflet-draw-draw-marker');
        if (markerBtn) {
            drawToolbar.insertBefore(btn, markerBtn);
        } else {
            drawToolbar.appendChild(btn);
        }
    })();

    // Add hint overlay at bottom-center of map when no bbox is selected
    var hintDiv = document.createElement('div');
    hintDiv.className = 'bbox-hint-overlay';
    hintDiv.innerHTML = 'Use the <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: -2px; opacity: 0.85;"><rect x="3" y="3" width="18" height="18"></rect></svg> tool to draw a custom area';
    map.getContainer().appendChild(hintDiv);

    // Add world preview button to the edit toolbar after drawControl is added
    addWorldPreviewToEditToolbar();
    /*
    **
    **  create bounds layer
    **  and default it at first
    **  to draw on null island
    **  so it's not seen onload
    **
    */
    startBounds = new L.LatLngBounds([0.0, 0.0], [0.0, 0.0]);
    var bounds = new L.Rectangle(startBounds, {
        color: '#3778d4',
        opacity: 1.0,
        weight: 3,
        fill: '#3778d4',
        lineCap: 'round',
        lineJoin: 'round'
    });

    bounds.on('bounds-set', function (e) {
        // move it to the end of the parent if renderer exists
        if (e.target._renderer && e.target._renderer._container) {
            var parent = e.target._renderer._container.parentElement;
            $(parent).append(e.target._renderer._container);
        }

        // Set the hash
        var southwest = this.getBounds().getSouthWest();
        var northeast = this.getBounds().getNorthEast();
        var xmin = southwest.lng.toFixed(6);
        var ymin = southwest.lat.toFixed(6);
        var xmax = northeast.lng.toFixed(6);
        var ymax = northeast.lat.toFixed(6);
        location.hash = ymin + ',' + xmin + ',' + ymax + ',' + xmax;
    });
    map.addLayer(bounds);

    // Show a brief toast notification on the map
    function showRotationToast(message) {
        // Remove any existing toast
        var existing = map.getContainer().querySelector('.rotation-toast');
        if (existing) existing.remove();

        var toast = document.createElement('div');
        toast.className = 'rotation-toast';
        toast.textContent = message;
        map.getContainer().appendChild(toast);

        setTimeout(function() {
            toast.classList.add('fade-out');
            setTimeout(function() { toast.remove(); }, 600);
        }, 6000);
    }

    map.on('draw:created', function (e) {
        // Hide the hint overlay when a bbox area is drawn
        if (e.layerType === 'rectangle') {
            var hint = document.querySelector('.bbox-hint-overlay');
            if (hint) hint.style.display = 'none';
        }

        // If it's a marker, make sure we only have one
        if (e.layerType === 'marker') {
            // Remove any existing markers
            drawnItems.eachLayer(function(layer) {
                if (layer instanceof L.Marker) {
                    drawnItems.removeLayer(layer);
                }
            });
        }

        // If it's a rectangle, remove any existing rectangles first
        if (e.layerType === 'rectangle') {
            drawnItems.eachLayer(function(layer) {
                if (layer instanceof L.Rectangle) {
                    drawnItems.removeLayer(layer);
                }
            });
        }

        // Check if it's a rectangle and set proper styles before adding it to the layer
        if (e.layerType === 'rectangle') {
            e.layer.setStyle({
                color: '#3778d4',
                opacity: 1.0,
                weight: 3,
                fill: '#3778d4',
                lineCap: 'round',
                lineJoin: 'round'
            });
        }

        drawnItems.addLayer(e.layer);

        // Only update the bounds based on non-marker layers
        if (e.layerType !== 'marker') {
            // Calculate bounds only from non-marker layers
            const nonMarkerBounds = new L.LatLngBounds();
            let hasNonMarkerLayers = false;
            
            drawnItems.eachLayer(function(layer) {
                if (!(layer instanceof L.Marker)) {
                    hasNonMarkerLayers = true;
                    nonMarkerBounds.extend(layer.getBounds());
                }
            });
            
            // Only update bounds if there are non-marker layers
            if (hasNonMarkerLayers) {
                bounds.setBounds(nonMarkerBounds);
                $('#boxbounds').text(formatBounds(bounds.getBounds(), '4326'));
                $('#boxboundsmerc').text(formatBounds(bounds.getBounds(), currentproj));
                notifyBboxUpdate();
            }
        }

        if (!e.geojson &&
            !((drawnItems.getLayers().length == 1) && (drawnItems.getLayers()[0] instanceof L.Marker))) {
            map.fitBounds(bounds.getBounds());
        } else {
            if ((drawnItems.getLayers().length == 1) && (drawnItems.getLayers()[0] instanceof L.Marker)) {
                map.panTo(drawnItems.getLayers()[0].getLatLng());
            }
        }
    });

    map.on('draw:deleted', function (e) {
        e.layers.eachLayer(function (l) {
            drawnItems.removeLayer(l);
        });

        // Show hint overlay again if no rectangles remain
        var hasRectangle = false;
        drawnItems.eachLayer(function(layer) {
            if (layer instanceof L.Rectangle) hasRectangle = true;
        });
        if (!hasRectangle) {
            var hint = document.querySelector('.bbox-hint-overlay');
            if (hint) hint.style.display = '';
        }

        if (drawnItems.getLayers().length > 0 &&
            !((drawnItems.getLayers().length == 1) && (drawnItems.getLayers()[0] instanceof L.Marker))) {
            bounds.setBounds(drawnItems.getBounds())
            $('#boxbounds').text(formatBounds(bounds.getBounds(), '4326'));
            $('#boxboundsmerc').text(formatBounds(bounds.getBounds(), currentproj));
            notifyBboxUpdate();
            map.fitBounds(bounds.getBounds());
        } else {
            bounds.setBounds(new L.LatLngBounds([0.0, 0.0], [0.0, 0.0]));
            $('#boxbounds').text(formatBounds(bounds.getBounds(), '4326'));
            $('#boxboundsmerc').text(formatBounds(bounds.getBounds(), currentproj));
            notifyBboxUpdate();
            if (drawnItems.getLayers().length == 1) {
                map.panTo(drawnItems.getLayers()[0].getLatLng());
            }
        }
    });

    map.on('draw:edited', function (e) {
        // Calculate bounds only from non-marker layers
        const nonMarkerBounds = new L.LatLngBounds();
        let hasNonMarkerLayers = false;
        
        drawnItems.eachLayer(function(layer) {
            if (!(layer instanceof L.Marker)) {
                hasNonMarkerLayers = true;
                nonMarkerBounds.extend(layer.getBounds());
            }
        });
        
        // Only update bounds if there are non-marker layers
        if (hasNonMarkerLayers) {
            bounds.setBounds(nonMarkerBounds);
        }
        
        $('#boxbounds').text(formatBounds(bounds.getBounds(), '4326'));
        $('#boxboundsmerc').text(formatBounds(bounds.getBounds(), currentproj));
        notifyBboxUpdate();
        map.fitBounds(bounds.getBounds());
    });

    // Hide world preview overlay when entering edit or delete mode
    map.on('draw:editstart', function() {
        hideWorldOverlayTemporarily();
    });

    map.on('draw:deletestart', function() {
        hideWorldOverlayTemporarily();
    });

    // Restore world preview overlay when exiting edit or delete mode
    map.on('draw:editstop', function() {
        restoreWorldOverlay();
    });

    map.on('draw:deletestop', function() {
        restoreWorldOverlay();
    });
    function display() {
        $('#boxbounds').text(formatBounds(bounds.getBounds(), '4326'));
        $('#boxboundsmerc').text(formatBounds(bounds.getBounds(), currentproj));
        notifyBboxUpdate();
    }
    display();

    map.on('move', function (e) {
        crosshair.setLatLng(map.getCenter());
    });



    $('button#add').on('click', function (evt) {
        var sniffer = FormatSniffer({ data: $('div#rsidebar textarea').val() });
        var is_valid = sniffer.sniff();
        if (is_valid) {
            rsidebar.hide();
            $('#create-geojson a').toggleClass('enabled');
            map.fitBounds(bounds.getBounds());
        }
    });
    $('button#clear').on('click', function (evt) {
        $('div#rsidebar textarea').val('');
    });

    var initialBBox = location.hash ? location.hash.replace(/^#/, '') : null;
    if (initialBBox) {
        if (validateStringAsBounds(initialBBox)) {
            var splitBounds = initialBBox.split(',');
            startBounds = new L.LatLngBounds([splitBounds[0], splitBounds[1]],
                [splitBounds[2], splitBounds[3]]);
            var lyr = new L.Rectangle(startBounds, {
                color: '#3778d4',
                opacity: 1.0,
                weight: 3,
                fill: '#3778d4',
                lineCap: 'round',
                lineJoin: 'round'
            });
            var evt = {
                layer: lyr,
                layerType: "polygon",
            }
            map.fire('draw:created', evt);
            //map.fitBounds(bounds.getBounds());
        } else {
            // This will reset the hash if the original hash was not valid
            bounds.setBounds(bounds.getBounds());
        }
    } else {
        // Initially set the hash if there was not one set by the user
        bounds.setBounds(bounds.getBounds());
    }

    $("input").click(function (e) {
        display();
    });

    // Store rotation angle for preview-skip logic (no mask drawn)
    window._rotationAngle = 0;

});

function notifyBboxUpdate() {
    const bboxText = document.getElementById('boxbounds').textContent;
    window.parent.postMessage({ bboxText: bboxText }, '*');
}

// Expose marker coordinates to the parent window
function getSpawnPointCoords() {
    // Check if there are any markers in drawn items
    const markers = [];
    drawnItems.eachLayer(function(layer) {
        if (layer instanceof L.Marker) {
            const latLng = layer.getLatLng();
            markers.push({
                lat: latLng.lat,
                lng: latLng.lng
            });
        }
    });

    // Return the first marker found or null if none exists
    return markers.length > 0 ? markers[0] : null;
}

// Expose the function to the parent window
window.getSpawnPointCoords = getSpawnPointCoords;
