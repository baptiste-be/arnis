export const licenseText = `
<b>Made with ♥️ in Munich by Louis Erbkamm</b>

<p>For a full list of contributors, please refer to the <a href="https://github.com/louis-e/arnis/graphs/contributors" style="color: inherit;" target="_blank">Github contributors page</a>. Logo made by nxfx21.

<p style="color: #ff8686;"><b>Download Arnis only from the official source:</b> <a href="https://arnismc.com" style="color: inherit;" target="_blank">https://arnismc.com</a> or <a href="https://github.com/louis-e/arnis" style="color: inherit;" target="_blank">https://github.com/louis-e/arnis/</a>. Every other website providing a download and claiming to be affiliated with the project is unofficial and may be malicious.</p>

<p><b>Third-Party Map Data and Tile Services:</b></p>
<p>This application uses map tiles from multiple providers, each with their own licensing requirements:</p>

<b>OpenStreetMap:</b><br> © <a href="https://www.openstreetmap.org/copyright" style="color: inherit;" target="_blank">OpenStreetMap</a> contributors
<br><br>

<b>Esri:</b><br> Tiles © Esri — Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community
<br><br>

<b>OpenTopoMap:</b><br> Map style: © <a href="https://opentopomap.org" style="color: inherit;" target="_blank">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/" style="color: inherit;" target="_blank">CC-BY-SA</a>), Map data: © OpenStreetMap contributors, <a href="http://viewfinderpanoramas.org" style="color: inherit;" target="_blank">SRTM</a>
<br><br>

<b>Stadia Maps:</b><br> © <a href="https://www.stadiamaps.com/" style="color: inherit;" target="_blank">Stadia Maps</a> © <a href="https://openmaptiles.org/" style="color: inherit;" target="_blank">OpenMapTiles</a> © OpenStreetMap contributors
<br><br>

<b>OpenFreeMap:</b><br> Vector tiles © <a href="https://openfreemap.org" style="color: inherit;" target="_blank">OpenFreeMap</a>, "Liberty" style © <a href="https://www.openmaptiles.org/" style="color: inherit;" target="_blank">OpenMapTiles</a>, map data © OpenStreetMap contributors
<p>Users of this software must comply with the respective licensing terms of these map data providers when using the application.</p>

<b>AWS Terrain Tiles:</b><br>
Elevation data derived from the <a href="https://registry.opendata.aws/terrain-tiles/" style="color: inherit;" target="_blank">AWS Terrain Tiles</a> dataset (global fallback).
<br><br>

<b>USGS 3D Elevation Program (3DEP):</b><br>
Elevation data provided by the <a href="https://www.usgs.gov/3d-elevation-program" style="color: inherit;" target="_blank">U.S. Geological Survey, 3D Elevation Program</a>. Public Domain.
<br><br>

<b>IGN France RGE ALTI:</b><br>
Elevation data &copy; <a href="https://geoservices.ign.fr/" style="color: inherit;" target="_blank">IGN France</a>, RGE ALTI. Licensed under <a href="https://www.etalab.gouv.fr/licence-ouverte-open-licence/" style="color: inherit;" target="_blank">Licence Ouverte 2.0</a>.
<br><br>

<b>IGN España MDT:</b><br>
Elevation data &copy; <a href="https://www.ign.es/" style="color: inherit;" target="_blank">Instituto Geogr&aacute;fico Nacional de Espa&ntilde;a</a>. Licensed under <a href="https://creativecommons.org/licenses/by/4.0/" style="color: inherit;" target="_blank">CC BY 4.0</a>.
<br><br>

<b>GSI Japan Elevation Tiles:</b><br>
Elevation data provided by the <a href="https://maps.gsi.go.jp/" style="color: inherit;" target="_blank">Geospatial Information Authority of Japan</a>.
<br><br>

<b>ESA WorldCover 2021:</b><br>
Land cover classification data provided by the <a href="https://esa-worldcover.org/en" style="color: inherit;" target="_blank">ESA WorldCover</a> project (10m resolution, v200). Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium. Licensed under <a href="https://creativecommons.org/licenses/by/4.0/" style="color: inherit;" target="_blank">CC-BY 4.0</a>. &copy; ESA WorldCover project 2021.
<br><br>

<b>bedrock-rs:</b><br>
Bedrock Edition world format support uses the <a href="https://github.com/bedrock-crustaceans/bedrock-rs" style="color: inherit;" target="_blank">bedrock-rs</a> library, licensed under the Apache License 2.0.
<br><br>

<b>MC2MT:</b><br>
The Luanti block mapping (<code>src/luanti_block_map.rs</code>) is derived from <a href="https://github.com/rollerozxa/MC2MT" style="color: inherit;" target="_blank">MC2MT</a> by rollerozxa. Licensed under <a href="https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html" style="color: inherit;" target="_blank">LGPL-2.1-or-later</a>.
<br><br>

<b>Mineclonia:</b><br>
Generated Luanti worlds use the <a href="https://content.luanti.org/packages/Mineclonia/mineclonia/" style="color: inherit;" target="_blank">Mineclonia</a> game pack for Luanti. Mineclonia is independent of and not associated with Mojang or Microsoft.
<br><br>

<b>Luanti (formerly Minetest):</b><br>
Luanti world export targets the <a href="https://www.luanti.org" style="color: inherit;" target="_blank">Luanti</a> engine, licensed under <a href="https://github.com/luanti-org/luanti/blob/master/LICENSE.txt" style="color: inherit;" target="_blank">LGPL-2.1+</a>.
<br><br>

<p><b>Third-Party JavaScript Libraries:</b></p>
<p>The map picker bundles the following libraries:</p>

<b><a href="https://leafletjs.com" style="color: inherit;" target="_blank">Leaflet</a> 1.9.4:</b> © 2010-2023 Vladimir Agafonkin, © 2010-2011 CloudMade. BSD-2-Clause.
<br><br>

<b><a href="https://github.com/Leaflet/Leaflet.draw" style="color: inherit;" target="_blank">Leaflet.draw</a> 1.0.4:</b> © 2012-2017 Jacob Toye, Jon West, Smartrak, Leaflet. MIT.
<br><br>

<b><a href="https://github.com/Turbo87/leaflet-sidebar" style="color: inherit;" target="_blank">L.Control.Sidebar</a>:</b> © Tobias Bieniek, customized for this project. MIT.
<br><br>

<b><a href="https://github.com/proj4js/proj4js" style="color: inherit;" target="_blank">proj4js</a>:</b> © 2014 Mike Adair, Richard Greenwood, Didier Richard, Stephen Irons, Olivier Terral, Calvin Metcalf. MIT.
<br><br>

<b><a href="https://github.com/kartena/Proj4Leaflet" style="color: inherit;" target="_blank">Proj4Leaflet</a> 1.0.2:</b> © 2013-2016 Kartena AB. BSD-2-Clause.
<br><br>

<b><a href="https://github.com/arthur-e/Wicket" style="color: inherit;" target="_blank">Wicket (WKT parser)</a>:</b> © Arthur Endsley. GPL.
<br><br>

<b><a href="https://maplibre.org" style="color: inherit;" target="_blank">MapLibre GL JS</a> 5.6.0:</b> © MapLibre contributors. BSD-3-Clause.
<br><br>

<b><a href="https://github.com/maplibre/maplibre-gl-leaflet" style="color: inherit;" target="_blank">maplibre-gl-leaflet</a> 0.1.3:</b> © 2021 MapLibre contributors, © 2014 Mapbox. ISC.
<br><br>

<b><a href="https://jquery.com" style="color: inherit;" target="_blank">jQuery</a> 1.9.1:</b> © jQuery Foundation. MIT.
<br><br>

<b><a href="https://jqueryui.com" style="color: inherit;" target="_blank">jQuery UI</a> 1.10.3:</b> © jQuery Foundation and contributors. MIT.
<br><br>

<p><b>Privacy Policy:</b></p>
If you consent to telemetry data collection, please review our Privacy Policy at:
<a href="https://arnismc.com/privacypolicy.html" style="color: inherit;" target="_blank">https://arnismc.com/privacypolicy.html</a>.

<p>NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG OR MICROSOFT.</p>

<p><b>License:</b></p>
<pre style="white-space: pre-wrap; font-family: inherit;">
Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

"License" shall mean the terms and conditions for use, reproduction,and distribution as defined by Sections 1 through 9 of this document.

"Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.

"Legal Entity" shall mean the union of the acting entity and allother entities that control, are controlled by, or are under commoncontrol with that entity. For the purposes of this definition,"control" means (i) the power, direct or indirect, to cause thedirection or management of such entity, whether by contract orotherwise, or (ii) ownership of fifty percent (50%) or more of theoutstanding shares, or (iii) beneficial ownership of such entity.

"You" (or "Your") shall mean an individual or Legal Entityexercising permissions granted by this License.

"Source" form shall mean the preferred form for making modifications,including but not limited to software source code, documentationsource, and configuration files.

"Object" form shall mean any form resulting from mechanicaltransformation or translation of a Source form, including butnot limited to compiled object code, generated documentation,and conversions to other media types.

"Work" shall mean the work of authorship, whether in Source orObject form, made available under the License, as indicated by acopyright notice that is included in or attached to the work(an example is provided in the Appendix below).

"Derivative Works" shall mean any work, whether in Source or Objectform, that is based on (or derived from) the Work and for which theeditorial revisions, annotations, elaborations, or other modificationsrepresent, as a whole, an original work of authorship. For the purposesof this License, Derivative Works shall not include works that remainseparable from, or merely link (or bind by name) to the interfaces of,the Work and Derivative Works thereof.

"Contribution" shall mean any work of authorship, includingthe original version of the Work and any modifications or additionsto that Work or Derivative Works thereof, that is intentionallysubmitted to Licensor for inclusion in the Work by the copyright owneror by an individual or Legal Entity authorized to submit on behalf ofthe copyright owner. For the purposes of this definition, "submitted"means any form of electronic, verbal, or written communication sentto the Licensor or its representatives, including but not limited tocommunication on electronic mailing lists, source code control systems,and issue tracking systems that are managed by, or on behalf of, theLicensor for the purpose of discussing and improving the Work, butexcluding communication that is conspicuously marked or otherwisedesignated in writing by the copyright owner as "Not a Contribution."

"Contributor" shall mean Licensor and any individual or Legal Entityon behalf of whom a Contribution has been received by Licensor andsubsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions ofthis License, each Contributor hereby grants to You a perpetual,worldwide, non-exclusive, no-charge, royalty-free, irrevocablecopyright license to reproduce, prepare Derivative Works of,publicly display, publicly perform, sublicense, and distribute theWork and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions ofthis License, each Contributor hereby grants to You a perpetual,worldwide, non-exclusive, no-charge, royalty-free, irrevocable(except as stated in this section) patent license to make, have made,use, offer to sell, sell, import, and otherwise transfer the Work,where such license applies only to those patent claims licensableby such Contributor that are necessarily infringed by theirContribution(s) alone or by combination of their Contribution(s)with the Work to which such Contribution(s) was submitted. If Youinstitute patent litigation against any entity (including across-claim or counterclaim in a lawsuit) alleging that the Workor a Contribution incorporated within the Work constitutes director contributory patent infringement, then any patent licensesgranted to You under this License for that Work shall terminateas of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of theWork or Derivative Works thereof in any medium, with or withoutmodifications, and in Source or Object form, provided that Youmeet the following conditions:

(a) You must give any other recipients of the Work or    Derivative Works a copy of this License; and

(b) You must cause any modified files to carry prominent notices    stating that You changed the files; and

(c) You must retain, in the Source form of any Derivative Works    that You distribute, all copyright, patent, trademark, and    attribution notices from the Source form of the Work,    excluding those notices that do not pertain to any part of    the Derivative Works; and

(d) If the Work includes a "NOTICE" text file as part of its    distribution, then any Derivative Works that You distribute must    include a readable copy of the attribution notices contained    within such NOTICE file, excluding those notices that do not    pertain to any part of the Derivative Works, in at least one    of the following places: within a NOTICE text file distributed    as part of the Derivative Works; within the Source form or    documentation, if provided along with the Derivative Works; or,    within a display generated by the Derivative Works, if and    wherever such third-party notices normally appear. The contents    of the NOTICE file are for informational purposes only and    do not modify the License. You may add Your own attribution    notices within Derivative Works that You distribute, alongside    or as an addendum to the NOTICE text from the Work, provided    that such additional attribution notices cannot be construed    as modifying the License.

You may add Your own copyright statement to Your modifications andmay provide additional or different license terms and conditionsfor use, reproduction, or distribution of Your modifications, orfor any such Derivative Works as a whole, provided Your use,reproduction, and distribution of the Work otherwise complies withthe conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,any Contribution intentionally submitted for inclusion in the Workby You to the Licensor shall be under the terms and conditions ofthis License, without any additional terms or conditions.Notwithstanding the above, nothing herein shall supersede or modifythe terms of any separate license agreement you may have executedwith Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the tradenames, trademarks, service marks, or product names of the Licensor,except as required for reasonable and customary use in describing theorigin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law oragreed to in writing, Licensor provides the Work (and eachContributor provides its Contributions) on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express orimplied, including, without limitation, any warranties or conditionsof TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR APARTICULAR PURPOSE. You are solely responsible for determining theappropriateness of using or redistributing the Work and assume anyrisks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,whether in tort (including negligence), contract, or otherwise,unless required by applicable law (such as deliberate and grosslynegligent acts) or agreed to in writing, shall any Contributor beliable to You for damages, including any direct, indirect, special,incidental, or consequential damages of any character arising as aresult of this License or out of the use or inability to use theWork (including but not limited to damages for loss of goodwill,work stoppage, computer failure or malfunction, or any and allother commercial damages or losses), even if such Contributorhas been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributingthe Work or Derivative Works thereof, You may choose to offer,and charge a fee for, acceptance of support, warranty, indemnity,or other liability obligations and/or rights consistent with thisLicense. However, in accepting such obligations, You may act onlyon Your own behalf and on Your sole responsibility, not on behalfof any other Contributor, and only if You agree to indemnify,defend, and hold each Contributor harmless for any liabilityincurred by, or claims asserted against, such Contributor by reasonof your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS

Copyright ${new Date().getFullYear()} Louis Erbkamm

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License athttp://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions andlimitations under the License.
</pre>
`;
